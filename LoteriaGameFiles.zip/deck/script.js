const NUM_IMAGES = 72;
const IMAGE_PATH = '../../game/images/';
const IMAGE_EXTENSION = '.jpg';

const carouselContainer = document.querySelector('.carousel-container');

// Create an array with the numbers from 1 to NUM_IMAGES
const imageIndexes = Array.from({ length: NUM_IMAGES }, (_, index) => index + 1);

// Shuffle the elements of an array randomly without duplicates
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  // Remove duplicates
  return [...new Set(array)];
}
;

// array of image file names
const images = imageIndexes.map((index) =>  IMAGE_PATH + 'image (' + index + ')' + IMAGE_EXTENSION);

let currentIndex = 0;
let usedImages = [];

function updateCarouselImage() {
  const unusedImages = images.filter(image => !usedImages.includes(image));
  if (unusedImages.length === 0) {
    usedImages = [];
    alert("End");
  }
  const randomIndex = Math.floor(Math.random() * unusedImages.length);
  const imgSrc = unusedImages[randomIndex];
  carouselImage.src = imgSrc;
  usedImages.push(imgSrc);
}

// function to cycle to the previous image
function prevImage() {
  currentIndex = (currentIndex - 1 + images.length) % images.length;
  updateCarouselImage();
}

// function to cycle to the next image
function nextImage() {
  currentIndex = (currentIndex + 1) % images.length;
  updateCarouselImage();
}

// function to reset the carousel image
function resetImage() {
  currentIndex = 0;
  shuffleArray(images); // Shuffle the images array
  usedImages = [];
  updateCarouselImage();
}


// add click event listeners to the buttons
const prevBtn = document.querySelector('.prev-btn');
prevBtn.addEventListener('click', prevImage);

const nextBtn = document.querySelector('.next-btn');
nextBtn.addEventListener('click', nextImage);

const resetBtn = document.querySelector('.reset-btn');
resetBtn.addEventListener('click', resetImage);

const carouselImage = document.querySelector('.carousel-image');
updateCarouselImage();

// Shuffle the elements of an array randomly
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}
