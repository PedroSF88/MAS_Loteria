const NUM_IMAGES = 57;
const IMAGE_PATH ='../../game/images/';
const IMAGE_EXTENSION = '.jpg';

const gridContainer = document.querySelector('.grid-container');

// Create an array with the numbers from 1 to NUM_IMAGES
const imageIndexes = Array.from({ length: NUM_IMAGES }, (_, index) => index + 1);

// Shuffle the array randomly
shuffleArray(imageIndexes);

// Create a grid item for each image and add it to the grid container
imageIndexes.slice(0, 16).forEach((index) => {
  const imgSrc = IMAGE_PATH + 'image (' + index + ')' + IMAGE_EXTENSION;
  const gridItem = document.createElement('div');
  const img = document.createElement('img');
  const overlay = document.createElement('div');
  img.src = imgSrc;
  gridItem.classList.add('grid-item');
  overlay.classList.add('overlay');
  gridItem.appendChild(img);
  gridItem.appendChild(overlay);
  gridContainer.appendChild(gridItem);
});

// Add event listener to each grid item
gridContainer.addEventListener('click', (event) => {
  const clickedItem = event.target.closest('.grid-item');
  if (clickedItem) {
    clickedItem.classList.toggle('clicked');
  }
});

// Shuffle the elements of an array randomly
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// Function to clear active selection
function clearSelection() {
  const clickedItems = document.querySelectorAll('.clicked');
  clickedItems.forEach((item) => {
    item.classList.remove('clicked');
  });
}

// Create a button element
const clearButton = document.createElement('button');
clearButton.textContent = 'Clear Card';
clearButton.classList.add('clear-button');

// Append the button to the document body
document.body.appendChild(clearButton);

// Add event listener to the clear button
clearButton.addEventListener('click', clearSelection);

